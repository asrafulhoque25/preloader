
$(window).on('load', function() { 
    $(".preloader").delay(5000).fadeOut(); 
    $('body').delay(1000).css({'overflow':'visible'});
})
